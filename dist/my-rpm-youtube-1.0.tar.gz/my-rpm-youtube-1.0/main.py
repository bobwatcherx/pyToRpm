import tkinter as tk
root = tk.Tk()

label = tk.Label(root,text="My RPM YOUTUBE",font=("Helvetica",30))

label.pack()

if __name__ == "__main__":
	root.mainloop()