from setuptools import setup

setup(
	name="my-rpm-youtube",
	version="1.0",
	description="a simple app test only",
	author="you author name",
	author_email="youemail@gmail.com",
	install_requires=['tkinter'],
	scripts=['main.py']

	)